Place songs for generation (not training) in here.

Acceptable: .mp3, .ogg, .wav