import os
import json
import glob
import pickle
import numpy as np
from collections import defaultdict
from tqdm import tqdm

def compile_chart_registry(json_dir='json/songs', output_file='chart_registry.pkl'):
    """
    Trawls through all processed song JSONs to build a mapping of difficulties, 
    BPMs, and lengths. Filters out charts where > 30% of the active beats 
    exceed 16th-note density (4 steps per beat).
    """
    registry = []
    
    search_path = os.path.join(json_dir, '**', '*.json')
    json_fps = glob.glob(search_path, recursive=True)
    
    print(f"Found {len(json_fps)} song JSON files. Extracting metadata...")
    skipped_dense_charts = 0
    
    for fp in tqdm(json_fps):
        try:
            with open(fp, 'r') as f:
                meta = json.load(f)
        except Exception as e:
            print(f"Skipping {fp} due to read error: {e}")
            continue
            
        bpms = meta.get('bpms', [])
        if not bpms:
            continue
            
        # Pacing features
        bpm_values = [b[1] for b in bpms]
        max_bpm = max(bpm_values)
        initial_bpm = bpms[0][1]
        
        for chart in meta.get('charts', []):
            if chart.get('type') == 'dance-double':
                continue
                
            notes = chart.get('notes', [])
            if not notes:
                continue
            
            # --- DENSITY FILTERING LOGIC ---
            # Group actual arrow inputs by their integer beat index
            beat_counts = defaultdict(int)
            for note in notes:
                # note format: [meas, beat, time, note_string]
                # '0000' means an empty row with no arrows
                if note[3] != '0000':
                    integer_beat = int(np.floor(note[1]))
                    beat_counts[integer_beat] += 1
            
            # Count beats where arrow density > 4 (signaling 24th or 32nd note bursts)
            high_density_beats = sum(1 for beat, count in beat_counts.items() if count > 4)
            total_active_beats = len(beat_counts)
            
            if total_active_beats > 0:
                high_density_ratio = high_density_beats / total_active_beats
                # If more than 30% of the played chart contains > 4 steps/beat, drop it
                if high_density_ratio > 0.30:
                    skipped_dense_charts += 1
                    continue
            # -------------------------------
            
            # Absolute time of the last note determines the song's duration
            length_seconds = notes[-1][2]
            
            # Cast difficulty strictly to integer as requested
            diff = chart.get('difficulty_fine')
            try:
                diff = int(round(float(diff))) if '.' in str(diff) else int(diff)
            except (ValueError, TypeError):
                pass
            
            registry.append({
                'pack': meta.get('pack'),
                'title': meta.get('title'),
                'difficulty': diff,
                'bpm': max_bpm,
                'initial_bpm': initial_bpm,
                'length_seconds': length_seconds,
                'json_path': os.path.abspath(fp)
            })
            
    # Save the clean registry matrix
    with open(output_file, 'wb') as f:
        pickle.dump(registry, f)
        
    print(f"\nFiltering complete!")
    print(f"Skipped {skipped_dense_charts} charts for exceeding 16th-note stream densities.")
    print(f"Successfully compiled registry with {len(registry)} model-friendly charts!")

if __name__ == '__main__':
    compile_chart_registry(json_dir='json/songs', output_file='chart_registry.pkl')