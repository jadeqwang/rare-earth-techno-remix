import torch
import torch.nn as nn
from util import *
from typing import Tuple
from vector_quantize_pytorch import ResidualVQ

class BasicEncoder(nn.Module):
    def __init__(
        self,
        in_channels: int,
        d_model: int,
        conv_dim: int = 32,
    ):
        super().__init__()

        self.cnn = nn.Sequential(
            nn.Conv2d(in_channels, conv_dim, kernel_size=(7, 3), stride=1, padding=0),
            nn.GELU(),
            nn.Conv2d(conv_dim, conv_dim, kernel_size=(3, 3), stride=(1,3) , padding=(1,0)),
            nn.GELU(),
            nn.Conv2d(conv_dim, conv_dim * 2, kernel_size=(3, 3), stride=1 , padding=0),
            nn.GELU(),
            nn.Conv2d(conv_dim*2, conv_dim*2, kernel_size=(3, 3), stride=(1,3) , padding=(1,0)),
            nn.GELU(),
            nn.Conv2d(conv_dim*2, conv_dim*2, kernel_size=(13, 3), padding=(0,1)),
            nn.GELU(),
        )

        self.norm = nn.RMSNorm(d_model)

        self.pool = nn.Linear(16 * conv_dim, d_model)

        self.proj = nn.Linear(d_model, d_model)

    def forward(self, x: torch.Tensor):
        B, T, S, Freq, C = x.shape
        # Flatten time into batch: [B * T, C, S, Freq]
        x = x.permute(0, 1, 4, 2, 3).contiguous().view(B * T, C, S, Freq)

        # CNN forward pass
        y = self.cnn(x)
        _, C_out, S_new, F_new = y.shape  # e.g., [B * T, conv_dim, S_new, F_new]
        y = y.permute(0, 2, 3, 1)
        y = y.reshape(B * T, -1)
        y = self.norm(self.pool(y))

        y_out = self.proj(y).view(B, T, -1)
        return y_out, 0
    


class NewStepConvEncoder(nn.Module):
    def __init__(
        self,
        in_channels: int,
        d_model: int,
        n_layers: int = 2,
        n_heads: int = 4,
        hidden_dim: int = 256,
        do_vq: bool = False,
        vq_dim: int = 128,
        num_codes: int = 512,
        conv_dim: int = 32,
    ):
        super().__init__()

        self.cnn = nn.Sequential(
            nn.Conv2d(in_channels, conv_dim, kernel_size=(7, 3), stride=1, padding=0),
            nn.GELU(),
            nn.Conv2d(conv_dim, conv_dim, kernel_size=(3, 3), stride=(1,3) , padding=(1,0)),
            nn.GELU(),
            nn.Conv2d(conv_dim, conv_dim * 2, kernel_size=(3, 3), stride=1 , padding=0),
            nn.GELU(),
            nn.Conv2d(conv_dim*2, vq_dim, kernel_size=(3, 3), stride=(1,3) , padding=(1,0)),
            nn.GELU(),
        )

        # 2D positional embeddings (moved before VQ)
        self.pos_emb_time = nn.Embedding(512, vq_dim)
        self.pos_emb_freq = nn.Embedding(512, vq_dim)
        self.pos_ln = nn.LayerNorm(vq_dim)  # normalize after pos injection

        self.do_vq = do_vq
        if self.do_vq:
            # VQ now sees position-aware patches
            self.vq = ResidualVQ(
                dim=vq_dim,
                num_quantizers=4,
                codebook_size=num_codes,
                decay=0.99,
                commitment_weight=0.25,
                threshold_ema_dead_code=2,
                kmeans_init=True,
                use_cosine_sim=True,
                shared_codebook=False,
            )

        # Transformer over quantized, position-aware patches
        ffn_dim = max(hidden_dim, vq_dim * 4)
        encoder_layer = nn.TransformerEncoderLayer(
            d_model=vq_dim, nhead=n_heads,
            dim_feedforward=ffn_dim,
            dropout=0.1, batch_first=True
        )
        self.transformer = nn.TransformerEncoder(encoder_layer, num_layers=n_layers)
        self.seq_pool = nn.Linear(vq_dim, 1)

        # CNN bypass path (regularized)
        self.cnn_ff = nn.Sequential(
            nn.Linear(vq_dim, hidden_dim),
            nn.GELU(),
            nn.Dropout(0.1),
            nn.Linear(hidden_dim, vq_dim),
            nn.Dropout(0.15),
        )

        # Per-channel gate (was scalar, now vq_dim)
        self.gate_net = nn.Sequential(
            nn.Linear(2 * vq_dim, vq_dim),
            nn.GELU(),
            nn.Linear(vq_dim, vq_dim),
        )

        self.proj = nn.Linear(vq_dim, d_model)
        self.layer_norm = nn.RMSNorm(vq_dim)

    def forward(self, x: torch.Tensor):
        B, T, S, Freq, C = x.shape
        x = x.permute(0, 1, 4, 2, 3).contiguous().view(B*T, C, S, Freq)

        y = self.cnn(x)
        _, C_out, S_new, F_new = y.shape

        # Build and inject positional embeddings BEFORE VQ
        pos_time = torch.arange(S_new, device=x.device).unsqueeze(1).expand(S_new, F_new)
        pos_freq = torch.arange(F_new, device=x.device).unsqueeze(0).expand(S_new, F_new)
        pos_emb = (
            self.pos_emb_time(pos_time) + self.pos_emb_freq(pos_freq)
        ).view(1, S_new * F_new, C_out)

        y_seq = y.permute(0, 2, 3, 1).contiguous().view(B*T, S_new*F_new, C_out)
        y_seq = self.layer_norm(y_seq)
 

        # VQ on position-aware patches
        if self.do_vq:
            y_q, _, vq_loss = self.vq(y_seq)
            vq_loss = vq_loss.mean()
        else:
            y_q = y_seq
            vq_loss = 0
        y_q = y_q + pos_emb

        # Transformer attends over position-encoded quantized patches
        y_trans = self.transformer(y_q)

        # Attention pooling over transformer output
        attn_weights = torch.softmax(self.seq_pool(y_trans).squeeze(-1), dim=-1)
        y_trans_pooled = torch.bmm(attn_weights.unsqueeze(1), y_trans).squeeze(1)

        # CNN bypass: global spectral summary (regularized)
        y_cnn_pool = y.mean(dim=(2, 3))
        y_cnn_ff = self.cnn_ff(y_cnn_pool)

        # Per-channel gate fusion
        gate_in = torch.cat([y_trans_pooled, y_cnn_ff], dim=-1)
        gate = torch.sigmoid(self.gate_net(gate_in))          # (B*T, vq_dim)
        y = (1 - gate) * y_trans_pooled + gate * y_cnn_ff

        y = self.proj(y).view(B, T, -1)
        return y, vq_loss
    
#==============LEGACY CODE===================

class DDCStepConvEncoder(nn.Module):
    def __init__(
        self,
        in_channels: int,
        d_model: int,
        n_layers: int = 2,
        n_heads: int = 4,
        hidden_dim: int = 256,
        do_vq: bool = False,
        vq_dim: int = 128,
        num_codes: int = 512,
        conv_dim: int = 32,
    ):
        super().__init__()

        # 1. (7,3) pass with no padding
        # 2. Max pooling with a (1,3) kernel and (1,3) stride
        # 3. (3,3) kernel with no padding
        # 4. Max pooling layer at the bottom with a (1,3) kernel and (1,3) stride
        self.cnn = nn.Sequential(
            # First Conv Pass
            nn.Conv2d(in_channels, conv_dim, kernel_size=(7, 3), padding=0),
            nn.GELU(),
            # First MaxPool (Frequency shrunk by a third)
            nn.MaxPool2d(kernel_size=(1, 3), stride=(1, 3)),
            
            # Second Conv Pass
            nn.Conv2d(conv_dim, vq_dim, kernel_size=(3, 3), padding=0),
            nn.GELU(),
            # Final MaxPool at the bottom (Frequency shrunk by a third again)
            nn.MaxPool2d(kernel_size=(1, 3), stride=(1, 3)),
        )

        # 2D positional embeddings (moved before VQ)
        self.pos_emb_time = nn.Embedding(512, vq_dim)
        self.pos_emb_freq = nn.Embedding(512, vq_dim)
        self.pos_ln = nn.LayerNorm(vq_dim)  # normalize after pos injection

        self.do_vq = do_vq
        if self.do_vq:
            self.vq = ResidualVQ(
                dim=vq_dim,
                num_quantizers=4,
                codebook_size=num_codes,
                decay=0.99,
                commitment_weight=0.25,
                threshold_ema_dead_code=2,
                kmeans_init=True,
                use_cosine_sim=True,
                shared_codebook=False,
            )

        # Transformer over quantized, position-aware patches
        ffn_dim = max(hidden_dim, vq_dim * 4)
        encoder_layer = nn.TransformerEncoderLayer(
            d_model=vq_dim, nhead=n_heads,
            dim_feedforward=ffn_dim,
            dropout=0.1, batch_first=True
        )
        self.transformer = nn.TransformerEncoder(encoder_layer, num_layers=n_layers)
        self.seq_pool = nn.Linear(vq_dim, 1)

        # CNN bypass path (regularized)
        self.cnn_ff = nn.Sequential(
            nn.Linear(vq_dim, hidden_dim),
            nn.GELU(),
            nn.Dropout(0.1),
            nn.Linear(hidden_dim, vq_dim),
            nn.Dropout(0.15),
        )

        # Per-channel gate (was scalar, now vq_dim)
        self.gate_net = nn.Sequential(
            nn.Linear(2 * vq_dim, vq_dim),
            nn.GELU(),
            nn.Linear(vq_dim, vq_dim),
        )

        self.proj = nn.Linear(vq_dim, d_model)
        self.layer_norm = nn.LayerNorm(vq_dim)

    def forward(self, x: torch.Tensor):
        B, T, S, Freq, C = x.shape
        x = x.permute(0, 1, 4, 2, 3).contiguous().view(B*T, C, S, Freq)

        y = self.cnn(x)
        _, C_out, S_new, F_new = y.shape

        # Build and inject positional embeddings BEFORE VQ
        pos_time = torch.arange(S_new, device=x.device).unsqueeze(1).expand(S_new, F_new)
        pos_freq = torch.arange(F_new, device=x.device).unsqueeze(0).expand(S_new, F_new)
        pos_emb = (
            self.pos_emb_time(pos_time) + self.pos_emb_freq(pos_freq)
        ).view(1, S_new * F_new, C_out)

        y_seq = y.permute(0, 2, 3, 1).contiguous().view(B*T, S_new*F_new, C_out)
        y_seq = self.layer_norm(y_seq)
 

        # VQ on position-aware patches
        if self.do_vq:
            y_q, _, vq_loss = self.vq(y_seq)
            vq_loss = vq_loss.mean()
        else:
            y_q = y_seq
            vq_loss = 0
        y_q = y_q + pos_emb

        # Transformer attends over position-encoded quantized patches
        y_trans = self.transformer(y_q)

        # Attention pooling over transformer output
        attn_weights = torch.softmax(self.seq_pool(y_trans).squeeze(-1), dim=-1)
        y_trans_pooled = torch.bmm(attn_weights.unsqueeze(1), y_trans).squeeze(1)

        # CNN bypass: global spectral summary (regularized)
        y_cnn_pool = y.mean(dim=(2, 3))
        y_cnn_ff = self.cnn_ff(y_cnn_pool)

        # Per-channel gate fusion
        gate_in = torch.cat([y_trans_pooled, y_cnn_ff], dim=-1)
        gate = torch.sigmoid(self.gate_net(gate_in))          # (B*T, vq_dim)
        y = (1 - gate) * y_trans_pooled + gate * y_cnn_ff

        y = self.proj(y).view(B, T, -1)
        return y, vq_loss