Add songs here as you would in Stepmania or ITGmania. File structure like:
```
ITGPT/raw/songs/<your folders here>
```