from dataclasses import dataclass

@dataclass
class ModelConfig:
    d_model: int = 512
    n_heads: int = 8
    n_self_pre: int = 6      
    n_self_audio_pre: int = 2 
    n_self_post: int = 6     
    n_cross: int = 2         
    dropout: float = 0.1
    max_len: int = 2048
    num_classes: int = 256   
    aux_dim: int = 2         
    VQ_dim: int = 128        
    VQ_codes: int = 512      
    conv_dim: int = 32
    pred_steps: int = 4  
    conv_layers: int = 4
    conv_heads: int = 4
    tok_dropout: float = 0.2