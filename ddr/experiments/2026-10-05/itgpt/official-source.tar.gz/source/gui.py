import os
import asyncio
import sys
from multiprocessing import Manager
from nicegui import ui, run
from generate_charts import generate_charts_gui 

from onset import OnsetModel, OnsetConfig
from sym import ITGPTSymModel as SymModel
from sym_config import ModelConfig as SymConfig
from sym_config import ModelConfig

# User-exposed controls are bound here, while backend-only settings 
# are safely maintained as fixed default values in this dictionary.
config = {
    'onset_model': 'trained_models/onset_stamina.pt',
    'sym_model': 'trained_models/sym_stamina.pt',
    'in_dir': 'input_songs_for_generation',
    'out_dir': 'generated_charts',
    'threshold': 0.5,
    'max_beats': 2000,
    'min_chunk': 1000,
    'edge_buffer': 500,
    'maxstep': 12,
    'bpm_method': 'AV',
    'frame_density': 32,
    'max_bpm': 200,
    'min_bpm': 100,
}

# ── Top-Level, Picklable Functions for Multiprocessing ─────────────────────────

def _process_log_worker(queue, message):
    queue.put(("log", str(message)))

def _process_progress_worker(queue, percentage, label_text):
    queue.put(("progress", (percentage, label_text)))

# ── Main Page Layout and Event Loop ───────────────────────────────────────────

@ui.page('/')
def main_page():
    
    async def log_listener(queue, terminal, progress_bar, progress_label):
        while True:
            while not queue.empty():
                msg_type, data = queue.get_nowait()
                if msg_type == "log":
                    terminal.push(data)
                elif msg_type == "progress":
                    percentage, label_text = data
                    progress_bar.set_value(percentage)
                    progress_label.set_text(label_text)
            await asyncio.sleep(0.05)

    async def start_generation():
        btn_run.disable()
        progress_bar.visible = True
        progress_label.visible = True
        log_terminal.push("Starting generation process...")
        
        if not os.path.exists(config['in_dir']):
            log_terminal.push(f"Error: Input directory '{config['in_dir']}' not found.")
            btn_run.enable()
            return

        with Manager() as manager:
            queue = manager.Queue()
            listener_task = asyncio.create_task(log_listener(queue, log_terminal, progress_bar, progress_label))

            try:
                import functools
                log_cb = functools.partial(_process_log_worker, queue)
                prog_cb = functools.partial(_process_progress_worker, queue)

                await run.cpu_bound(
                    generate_charts_gui,
                    onset_model_fp=config['onset_model'],
                    sym_model_fp=config['sym_model'],
                    threshold=config['threshold'],
                    max_beats=config['max_beats'],
                    min_chunk=config['min_chunk'],
                    edge_buffer=config['edge_buffer'],
                    in_directory=config['in_dir'],
                    out_directory=config['out_dir'],
                    maxstep=config['maxstep'],
                    bpm_method=config['bpm_method'],
                    model_frame_density=config['frame_density'],
                    max_bpm=config['max_bpm'],
                    min_bpm=config['min_bpm'],
                    log_callback=log_cb,
                    progress_callback=prog_cb

                )
            except Exception as e:
                log_terminal.push(f"An error occurred: {str(e)}")
            finally:
                await asyncio.sleep(0.5)
                listener_task.cancel()
                progress_bar.set_value(1.0)
                progress_label.set_text("Generation finished!")
                btn_run.enable()

    # ── UI Layout ────────────────────────────────────────────────────────
    ui.dark_mode(True)

    with ui.column().classes('w-full p-4 max-w-4xl mx-auto'):
        ui.label('ITGPT').classes('text-3xl font-bold mb-4')
        
        # Paths Card
        with ui.card().classes('w-full p-4 mb-4'):
            ui.label('Paths & Folders').classes('text-xl font-bold mb-2')
            with ui.grid(columns=2).classes('w-full gap-4'):
                ui.input('Onset Model Path').bind_value(config, 'onset_model').classes('w-full')
                ui.input('Symbolic Model Path').bind_value(config, 'sym_model').classes('w-full')
                ui.input('Input Songs Folder').bind_value(config, 'in_dir').classes('w-full')
                ui.input('Output Charts Folder').bind_value(config, 'out_dir').classes('w-full')

        # Settings Container
        with ui.column().classes('w-full gap-4 mb-4'):
            # Expandable Dropdown for advanced algorithm tuners
            with ui.expansion('Advanced Settings', icon='settings').classes('w-full border border-zinc-700 rounded'):
                with ui.grid(columns=2).classes('w-full p-4 gap-4'):
                    ui.number('Threshold', step=0.05).bind_value(config, 'threshold')
                    ui.select(['AV', 'SMEdit'], label='BPM Detection Method').bind_value(config, 'bpm_method')
                    ui.number('Max BPM').bind_value(config, 'max_bpm')
                    ui.number('Min BPM').bind_value(config, 'min_bpm')

        with ui.row().classes('w-full justify-center my-4'):
                btn_run = ui.button('Generate Charts', on_click=start_generation).classes('px-8 py-2 text-lg')

        # Change these lines to avoid chaining .set_visibility() during assignment:
        progress_label = ui.label('Waiting to start...').classes('text-sm text-zinc-400 mt-2')
        progress_label.visible = False

        progress_bar = ui.linear_progress(value=0.0, show_value=False).classes('w-full rounded')
        progress_bar.visible = False

        ui.label('Console Log').classes('text-lg font-bold mt-4')
        log_terminal = ui.log(max_lines=200).classes('w-full h-64 bg-zinc-900 font-mono text-xs text-green-400 p-2 rounded border border-zinc-700')

if __name__ == '__main__':
    from multiprocessing import freeze_support
    freeze_support()
    ui.run(
        title="ITGPT", 
        reload=False,  # Essential for PyInstaller compilation
        port=8080      # Explicitly binds it cleanly
    )