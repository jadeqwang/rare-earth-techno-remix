import os
import pickle
import numpy as np
import math
from typing import List, Tuple, Dict
import librosa


def set_bpm(audio_fp, min_tempo = 100, max_tempo = 200, maxstep = 12, bpm_method = 'AV'):
    if bpm_method == 'AV':
        # 1. Get the full list of results
        beat_results = arrow_vortex_get_bpm(audio_fp, bpm_range=(min_tempo, max_tempo))
        
        # 2. Extract the top candidate dictionary safely
        top_candidate = beat_results[0]
        bpm = top_candidate['bpm']
        offset = top_candidate['offset']
        beats = top_candidate['beats']
        
        bpm_shift_times = [(0, bpm)]
        subdiv_beats = []
        
        # 3. FIX: Safeguard against empty beat tracking
        if len(beats) > 0:
            for j in range(len(beats) - 1):
                for i in range(maxstep):
                    subdiv_beats.append(((beats[j] * (maxstep - i)) / maxstep) + (beats[j + 1] * i) / maxstep)
            subdiv_beats.append(beats[-1])
            song_length = beats[-1] / 60
        else:
            # Fallback values if the song has no discernable beats
            subdiv_beats = [0.0]
            song_length = 0.0
            
        bpm_str = '0.0={}'.format(bpm)
        return beats, np.array(subdiv_beats), bpm_shift_times, offset, bpm_str, song_length, bpm
    elif bpm_method == 'SMEdit':
        beat_dict = smedit_analyze_audio(audio_fp, bpm_range = (min_tempo, max_tempo))
        bpm = beat_dict['bpm_results'][0]['bpm']
        offset = beat_dict['offset_results'][0]['offset']
        beats = beat_dict['beat_times'][bpm]
        bpm_shift_times = [(0,bpm)]
        subdiv_beats = []
        for j in range(len(beats)-1):
            for i in range(maxstep):
                subdiv_beats.append(((beats[j]*(maxstep-i))/maxstep)+(beats[j+1]*i)/maxstep)
        subdiv_beats.append(beats[-1])
        bpm_str = '0.0={}'.format(bpm)
        song_length = beats[-1]/60
        return beats, np.array(subdiv_beats), bpm_shift_times, offset, bpm_str, song_length, bpm

def weighted_median(data):
    sorted_data = np.sort(data)
    n = len(sorted_data)
    if n % 2 == 1:
        return sorted_data[n // 2]
    else:
        return (sorted_data[n // 2 - 1] + sorted_data[n // 2]) / 2.0

def hamming_window(w):
    return [0.54 - 0.46 * math.cos(2 * math.pi * n / (w - 1)) for n in range(w)]


def create_hamming_window(n):
    """Creates weights for a hamming window of length n."""
    t = 2.0 * np.pi / (n - 1)
    return 0.54 - 0.46 * np.cos(np.arange(n) * t)

def normalize_fitness(fitness, coefs, interval):
    """Normalizes the fitness based on 3rd order poly coefficients and interval."""
    x = interval
    return fitness - (coefs[0] + coefs[1] * x + coefs[2] * (x ** 2) + coefs[3] * (x ** 3))

def compute_slopes(samples, sample_rate):
    """Computes slopes/envelope increments to detect positive changes in energy."""
    num_frames = len(samples)
    out = np.zeros(num_frames, dtype=np.float64)
    wh = sample_rate // 20
    if num_frames < wh * 2:
        return out

    abs_samples = np.abs(samples)
    cumsum = np.concatenate(([0], np.cumsum(abs_samples)))
    
    i_arr = np.arange(wh, num_frames - wh)
    sumL_arr = cumsum[i_arr] - cumsum[i_arr - wh]
    sumR_arr = cumsum[i_arr + wh] - cumsum[i_arr]
    
    scalar = 1.0 / float(wh)
    out[i_arr] = np.maximum(0.0, (sumR_arr - sumL_arr) * scalar)
    return out

def arrow_vortex_get_bpm(audio_file, 
                        window_size=1024, 
                        hop_size=256,
                        bpm_range=(89, 205),
                        silence_threshold=-70,
                        threshold_weight=0.1,
                        threshold_window_size=7):
    
    # 1. Load Audio via Librosa (Force native sampling rate, mono)
    audio, sample_rate = librosa.load(audio_file, sr=None, mono=True)
    num_frames = len(audio)
    min_bpm, max_bpm = bpm_range
    
    # 2. Find Onsets using Librosa's Spectral Flux Onset Envelope
    # librosa.onset.onset_strength defaults to a half-rectified spectral flux
    onset_envelope = librosa.onset.onset_strength(
        y=audio, 
        sr=sample_rate, 
        n_fft=window_size, 
        hop_length=hop_size
    )
    
    # Peak pick the onset events from the envelope
    onset_frames = librosa.onset.onset_detect(
        onset_envelope=onset_envelope, 
        sr=sample_rate, 
        hop_length=hop_size
    )
    
    # Convert frames back to sample positions
    onset_times = librosa.frames_to_time(onset_frames, sr=sample_rate, hop_length=hop_size)
    
    onsets = []
    for t_onset in onset_times:
        pos = int(t_onset * sample_rate)
        if pos < num_frames:
            onsets.append({'pos': pos, 'strength': 0.0})
            
    # Calculate onset strength for the first 100 entries exactly like the C++ algorithm
    for i in range(min(len(onsets), 100)):
        pos = onsets[i]['pos']
        a = max(0, pos - 100)
        b = min(num_frames, pos + 100)
        onsets[i]['strength'] = float(np.mean(np.abs(audio[a:b]))) if b > a else 0.0

    # Minimum threshold to track periodicity 
    if len(onsets) < 2:
        print("Best bpm, offset: 0.0, 0.0")
        return []

    # Constants mapping directly to the ArrowVortex C++ definitions
    interval_delta = 10
    interval_downsample = 3

    min_interval = int(sample_rate * 60.0 / max_bpm + 0.5)
    max_interval = int(sample_rate * 60.0 / min_bpm + 0.5)
    num_intervals = max_interval - min_interval

    fitness = np.zeros(num_intervals, dtype=np.float64)
    num_coarse_intervals = (num_intervals + interval_delta - 1) // interval_delta

    # Helper function matching GetConfidenceForInterval / GetConfidenceForBPM logic via NumPy
    def get_confidence(interval, downsample=0, target_bpm=None):
        if target_bpm is not None:
            intervalf = sample_rate * 60.0 / target_bpm
            reduced_interval = int(intervalf + 0.5)
            win_size = 2048
        else:
            intervalf = float(interval)
            reduced_interval = interval >> downsample
            win_size = 2048 >> downsample

        wrapped_onsets = np.zeros(reduced_interval, dtype=np.float64)
        wrapped_pos = []
        
        for onset in onsets:
            if target_bpm is not None:
                pos = int(onset['pos'] % intervalf)
            else:
                pos = (onset['pos'] % interval) >> downsample
                
            # FIX 1: Safely clamp/wrap pos so it cannot equal or exceed reduced_interval
            pos = pos % reduced_interval
                
            wrapped_pos.append(pos)
            wrapped_onsets[pos] += 1.0 if target_bpm is None and downsample == 1 else onset['strength']
                
        wrapped_pos = np.array(wrapped_pos)
        window = create_hamming_window(win_size)
        half_W = win_size // 2
        
        # Circular sliding-window padding
        indices = np.arange(-half_W, reduced_interval + half_W - 1)
        extended = np.take(wrapped_onsets, indices, mode='wrap')
        confidences = np.correlate(extended, window, mode='valid')
        
        if len(wrapped_pos) > 0:
            # FIX 2: Ensure offbeat calculation also stays strictly wrapped inside bounds
            offbeat_pos = (wrapped_pos + reduced_interval // 2) % reduced_interval
            
            combined = confidences[wrapped_pos] + confidences[offbeat_pos] * 0.5
            return np.max(combined), confidences
        return 0.0, confidences

    # 3. Fill Coarse Intervals
    x_coarse, y_coarse = [], []
    for i in range(num_coarse_intervals):
        index = i * interval_delta
        if index < num_intervals:
            interval = min_interval + index
            fit_val = max(0.001, get_confidence(interval, interval_downsample)[0])
            fitness[index] = fit_val
            x_coarse.append(interval)
            y_coarse.append(fit_val)

    # Calculate polynomial coefficients to normalize baseline trend curve
    poly_coefs = np.polyfit(x_coarse, y_coarse, 3)[::-1]
    
    max_fitness = 0.001
    for i in range(0, num_intervals, interval_delta):
        interval = min_interval + i
        fitness[i] = normalize_fitness(fitness[i], poly_coefs, interval)
        max_fitness = max(max_fitness, fitness[i])

    # 4. Refine Intervals
    fitness_threshold = max_fitness * 0.4
    tempo_candidates = []

    for i in range(0, num_intervals, interval_delta):
        if fitness[i] > fitness_threshold:
            begin = max(i - interval_delta, 0)
            end = min(i + interval_delta, num_intervals)
            
            for idx in range(begin, end):
                if fitness[idx] == 0:
                    interval = min_interval + idx
                    fit_val, _ = get_confidence(interval, interval_downsample)
                    fitness[idx] = max(normalize_fitness(fit_val, poly_coefs, interval), 0.1)
                    
            sub_fit = fitness[begin:end]
            if len(sub_fit) > 0:
                best_idx = np.argmax(sub_fit) + begin
                best_interval = min_interval + best_idx
                bpm_val = (sample_rate * 60.0) / best_interval
                tempo_candidates.append({'bpm': bpm_val, 'offset': 0.0, 'fitness': fitness[best_idx]})

    # 5. Remove Duplicates & Round BPM Values
    tempo_candidates.sort(key=lambda x: x['fitness'], reverse=True)
    
    # Remove near duplicate harmonic components
    i = 0
    while i < len(tempo_candidates):
        bpm = tempo_candidates[i]['bpm']
        j = len(tempo_candidates) - 1
        while j > i:
            v = tempo_candidates[j]['bpm']
            if min(abs(v - bpm), abs(v - bpm * 2.0), abs(v - bpm * 0.5)) < 0.1:
                tempo_candidates.pop(j)
            j -= 1
        i += 1

    # Close rounding checks
    for t in tempo_candidates:
        round_bpm = round(t['bpm'])
        diff = abs(t['bpm'] - round_bpm)
        if diff < 0.01:
            t['bpm'] = float(round_bpm)
        elif diff < 0.05:
            old_fit, _ = get_confidence(0, target_bpm=t['bpm'])
            cur_fit, _ = get_confidence(0, target_bpm=float(round_bpm))
            if normalize_fitness(cur_fit, poly_coefs, sample_rate * 60.0 / round_bpm) > normalize_fitness(old_fit, poly_coefs, sample_rate * 60.0 / t['bpm']) * 0.99:
                t['bpm'] = float(round_bpm)

    if len(tempo_candidates) >= 2 and (tempo_candidates[0]['fitness'] / tempo_candidates[1]['fitness']) < 1.05:
        for t in tempo_candidates:
            raw_fit, _ = get_confidence(0, target_bpm=t['bpm'])
            t['fitness'] = normalize_fitness(raw_fit, poly_coefs, sample_rate * 60.0 / t['bpm'])
        tempo_candidates.sort(key=lambda x: x['fitness'], reverse=True)

    if len(tempo_candidates) > 3:
        tempo_candidates = tempo_candidates[:3]

    # 6. Calculate Offsets & Align Beats
    slopes = compute_slopes(audio, sample_rate)
    final_results = []
    total_seconds = num_frames / sample_rate

    for t in tempo_candidates:
        bpm = t['bpm']
        seconds_per_beat = 60.0 / bpm
        
        # Get raw offset in seconds
        offset_seconds, confidence_arr = get_confidence(int(sample_rate * 60.0 / bpm + 0.5), downsample=1)
        
        # FIX: Ensure base offset is strictly smaller than one beat interval
        offset_seconds = offset_seconds % seconds_per_beat
        
        # Adjust for Offbeats Phase Realignment
        offbeat = offset_seconds + seconds_per_beat * 0.5
        if offbeat > seconds_per_beat:
            offbeat -= seconds_per_beat

        interval_samples = seconds_per_beat * sample_rate
        
        # Vectorized support evaluation
        steps_A = int((num_frames - (offset_seconds * sample_rate)) / interval_samples) + 1
        steps_B = int((num_frames - (offbeat * sample_rate)) / interval_samples) + 1
        
        idx_A_raw = (offset_seconds * sample_rate + np.arange(max(0, steps_A)) * interval_samples).astype(int)
        idx_A = idx_A_raw[idx_A_raw < num_frames]
        
        idx_B_raw = (offbeat * sample_rate + np.arange(max(0, steps_B)) * interval_samples).astype(int)
        idx_B = idx_B_raw[idx_B_raw < num_frames]
        
        sumA = np.sum(slopes[idx_A]) if len(idx_A) > 0 else 0.0
        sumB = np.sum(slopes[idx_B]) if len(idx_B) > 0 else 0.0
        
        final_offset = offset_seconds if sumA >= sumB else offbeat
        
        # Generate full sequencing map arrays
        beat_timings = []
        curr_beat = final_offset
        while curr_beat < total_seconds:
            if curr_beat >= 0:
                beat_timings.append(curr_beat)
            curr_beat += seconds_per_beat

        # Fallback if no beats were appended
        if not beat_timings:
            beat_timings = [final_offset]

        final_results.append({
            'bpm': bpm,
            'offset': final_offset,
            'fitness': t['fitness'],
            'confidence': np.max(confidence_arr) if len(confidence_arr) > 0 else 0.0,
            'beats': beat_timings,
        })

    if not final_results:
        final_results.append({'bpm': 0.0, 'offset': 0.0, 'fitness': 0.0, 'confidence': 0.0, 'beats': []})

    print(f"Best bpm, offset: {final_results[0]['bpm']}, {final_results[0]['offset']}")
    
    # FIX: Return the top candidate directly if your outer loop expects a dictionary
    #print(final_results)
    return final_results
    

class SMEditAudioSyncDetector:
    '''
    Instantiates a bpm detector imitating the one used in SMEditor. Similar to AV but with some process improvements.
    '''
    def __init__(self, 
                 window_step: int = 512,
                 fft_size: int = 1024,
                 tempo_fft_size: int = 4096,
                 tempo_step: int = 2,
                 min_bpm: float = 125,
                 max_bpm: float = 250,
                 sample_rate: int = 44100):
        
        self.window_step = window_step
        self.fft_size = fft_size
        self.tempo_fft_size = tempo_fft_size
        self.tempo_step = tempo_step
        self.min_bpm = min_bpm
        self.max_bpm = max_bpm
        self.sample_rate = sample_rate
        
        self.AVERAGE_WINDOW_RADIUS = 3
        self.TEMPOGRAM_SMOOTHING = 3
        self.TEMPOGRAM_OFFSET_THRESHOLD = 0.02
        self.TEMPOGRAM_GROUPING_WINDOW = 6
        self.OFFSET_LOOKAHEAD = 800
        
        # magic SMEdit numbers. I think these are supposed to replace the polyfit AV uses.
        self.weight_data = [
            (20, 0.4006009013520281), (25, 0.4258037044922291), (31.5, 0.4536690484291709),
            (40, 0.4840856831659204), (50, 0.5142710208279764), (63, 0.5473453749315819),
            (80, 0.5841121495327103), (100, 0.6214074879602299), (125, 0.6601749463607856),
            (160, 0.7054673721340388), (200, 0.7489234225800412), (250, 0.7936507936507937),
            (315, 0.8406893652795292), (400, 0.889284126278346), (500, 0.9291521486643438),
            (630, 0.9675858732462506), (800, 0.9985022466300548), (1000, 0.9997500624843789),
            (1250, 0.9564801530368244), (1600, 0.9409550693954364), (2000, 1.0196278358399185),
            (2500, 1.0955902492467817), (3150, 1.1232799775344005), (4000, 1.0914051841746248),
            (5000, 0.9997500624843789), (6300, 0.8727907484180668), (8000, 0.7722007722007722),
            (10000, 0.7369196757553427), (12500, 0.7768498737618955), (16000, 0.7698229407236336),
            (20000, 0.4311738708634257), (22550, 0.2), (25000, 0)
        ]
        
        self.spectro_weights = None
        self.audio_data = None
        self.spectrogram = []
        self.spectogram_difference = []
        self.novelty_curve = []
        self.novelty_curve_isolated = []
        self.tempogram = []
        self.tempogram_groups = []
        
    def load_audio(self, audio_path: str) -> np.ndarray:
        """Load audio file and convert to mono via librosa"""
        self.audio_data, _ = librosa.load(audio_path, sr=self.sample_rate, mono=True)
        return self.audio_data
    
    def _calculate_spectro_weights(self) -> np.ndarray:
        """Calculate frequency weights based on ISO 226 approximation"""
        num_bins = (self.fft_size // 2) + 1  # 513 bins
        weights = np.zeros(num_bins)
        
        for i in range(num_bins):
            freq = (i / (self.fft_size / 2)) * self.sample_rate / 2
            
            # Find the closest weight points
            weight_index = None
            for j, (weight_freq, _) in enumerate(self.weight_data):
                if weight_freq > freq:
                    weight_index = j
                    break
            
            if weight_index is None or weight_index == 0:
                weights[i] = 0
                continue
                
            # Linear interpolation in log space
            lower_freq, lower_weight = self.weight_data[weight_index - 1]
            higher_freq, higher_weight = self.weight_data[weight_index]
            
            log_freq = np.log(1 + freq)
            log_lower = np.log(1 + lower_freq)
            log_higher = np.log(1 + higher_freq)
            
            if log_higher != log_lower:
                t = (log_freq - log_lower) / (log_higher - log_lower)
                weights[i] = lower_weight + t * (higher_weight - lower_weight)
            else:
                weights[i] = lower_weight
                
        return weights
    
    def _calc_difference(self, block_num: int, current_spectrum: np.ndarray) -> np.ndarray:
        """Calculate spectral difference with previous block"""
        if block_num == 0:
            previous = np.zeros_like(current_spectrum)
        else:
            previous = self.spectrogram[block_num - 1]
            
        # Spectral flux with weighting
        diff = np.maximum(0, current_spectrum - previous) * self.spectro_weights
        return diff
    
    def _calc_isolated_novelty(self, block_num: int):
        """Calculate isolated novelty function with local averaging"""
        # Update blocks around current position
        for i in range(max(0, block_num - self.AVERAGE_WINDOW_RADIUS), block_num + 1):
            if i >= len(self.novelty_curve):
                continue
                
            # Calculate local average
            start_idx = max(0, i - self.AVERAGE_WINDOW_RADIUS)
            end_idx = min(len(self.novelty_curve), i + self.AVERAGE_WINDOW_RADIUS + 1)
            
            local_sum = sum(self.novelty_curve[start_idx:end_idx])
            local_avg = local_sum / (end_idx - start_idx)
            
            # Isolated novelty
            isolated = max(0, self.novelty_curve[i] - local_avg)
            
            # Extend list if necessary
            while len(self.novelty_curve_isolated) <= i:
                self.novelty_curve_isolated.append(0)
                
            self.novelty_curve_isolated[i] = np.log(1 + isolated)
    
    def detect_onsets(self, threshold: float = 0.3) -> List[float]:
        """Detect onset times based on novelty curve"""
        if self.audio_data is None:
            raise ValueError("Audio data not loaded")
            
        print("Computing spectrogram and novelty curve...")
        
        # Initialize weights
        self.spectro_weights = self._calculate_spectro_weights()
        
        # Calculate full magnitude spectrogram using librosa's STFT pipeline matching the old behavior
        # center=True pads the boundaries with reflection to mimic the window center offsets.
        stft_matrix = librosa.stft(
            y=self.audio_data, 
            n_fft=self.fft_size, 
            hop_length=self.window_step, 
            win_length=self.fft_size, 
            window='hann', 
            center=True
        )
        magnitude_spectrogram = np.abs(stft_matrix)
        
        # Log scale mapping and format conversion to match step-by-step block updates
        full_spectrogram = np.log(1 + magnitude_spectrogram).T
        max_blocks = len(full_spectrogram)
        
        # Reset arrays
        self.spectrogram = []
        self.spectogram_difference = []
        self.novelty_curve = []
        self.novelty_curve_isolated = []
        
        # Process each block
        for block_num in range(max_blocks):                
            spectrum = full_spectrogram[block_num]
            self.spectrogram.append(spectrum)
            
            # Calculate difference
            diff = self._calc_difference(block_num, spectrum)
            self.spectogram_difference.append(diff)
            
            # Sum for novelty curve
            novelty_sum = np.sum(diff)
            self.novelty_curve.append(novelty_sum)
            
            # Calculate isolated novelty
            self._calc_isolated_novelty(block_num)
        
        # Detect peaks
        peaks = []
        for i in range(1, len(self.novelty_curve_isolated)):
            if (self.novelty_curve_isolated[i] > threshold and 
                self.novelty_curve_isolated[i] > self.novelty_curve_isolated[i-1]):
                
                # Convert block to time
                time_seconds = (i * self.window_step) / self.sample_rate
                peaks.append(time_seconds)
                
        return peaks
    
    def detect_tempo_and_offset(self) -> Tuple[List[Dict], List[Dict]]:
        """Detect tempo and offset information"""
        if not self.novelty_curve_isolated:
            raise ValueError("Must run detect_onsets first")
        
        # Scale novelty curve to max 1
        novelty_array = np.array(self.novelty_curve_isolated)
        max_val = np.max(novelty_array)
        if max_val > 0:
            scaled_novelty = novelty_array / max_val
        else:
            scaled_novelty = novelty_array
        
        # Calculate tempogram
        max_tempo_blocks = int(np.ceil(len(scaled_novelty) / self.tempo_step))
        self.tempogram = []
        self.tempogram_groups = []
        
        for block_num in range(max_tempo_blocks):   
            # Extract slice for tempo analysis
            start_idx = max(0, block_num * self.tempo_step - self.tempo_fft_size // 2)
            end_idx = block_num * self.tempo_step + self.tempo_fft_size // 2
            
            tempo_slice = np.zeros(self.tempo_fft_size, dtype=np.float32)
            
            # Handle boundaries
            data_start = max(0, start_idx)
            data_end = min(len(scaled_novelty), end_idx)
            slice_start = data_start - start_idx
            slice_end = slice_start + (data_end - data_start)
            
            if data_end > data_start:
                tempo_slice[slice_start:slice_end] = scaled_novelty[data_start:data_end]
            
            # Apply Hann window and FFT
            windowed = tempo_slice * np.hanning(self.tempo_fft_size)
            fft_result = np.fft.fft(windowed)
            response = np.abs(fft_result[:self.tempo_fft_size//2])
            
            # Log scale
            response = np.log(1 + response)
            
            # Convert FFT bins to BPM
            tempos = {}
            for i, value in enumerate(response):
                if value == 0:
                    continue
                    
                # Calculate BPM from FFT bin
                tmp = (self.sample_rate * 60) / (self.window_step * self.tempo_fft_size) * i
                
                if tmp > self.max_bpm * 4 or tmp < self.min_bpm / 4:
                    continue
                    
                # Octave reduction
                while tmp > self.max_bpm and not np.isinf(tmp):
                    tmp /= 2
                while tmp < self.min_bpm and tmp != 0:
                    tmp *= 2
                    
                bpm = round(tmp, 3)
                if bpm not in tempos:
                    tempos[bpm] = 0
                tempos[bpm] += value
            
            # Sort by confidence
            tempo_list = [{'bpm': bpm, 'value': value} for bpm, value in tempos.items()]
            tempo_list.sort(key=lambda x: x['value'], reverse=True)
            self.tempogram.append(tempo_list[:10])  # Keep top 10
            
            # Group similar tempos
            groups = []
            for tempo in tempo_list[:10]:
                # Find closest group
                closest_group = None
                for group in groups:
                    if (abs(group['center'] - tempo['bpm']) < self.TEMPOGRAM_GROUPING_WINDOW):
                        closest_group = group
                        break
                
                if closest_group is None:
                    groups.append({
                        'center': tempo['bpm'],
                        'groups': [tempo],
                        'avg': tempo['bpm']
                    })
                else:
                    closest_group['groups'].append(tempo)
                    total_weight = sum(g['value'] for g in closest_group['groups'])
                    weighted_sum = sum(g['bpm'] * g['value'] for g in closest_group['groups'])
                    closest_group['avg'] = weighted_sum / total_weight if total_weight > 0 else tempo['bpm']
            
            self.tempogram_groups.append(groups)
        
        # Extract top BPMs and calculate offsets
        return self._calculate_bpm_and_offset()
    
    def _calculate_bpm_and_offset(self) -> Tuple[List[Dict], List[Dict]]:
        """Calculate final BPM and offset results"""
        print("Calculating BPM and offset results...")
        
        # Find most consistent BPM
        bpm_counts = {}
        peak_scan_start = 0
        
        for i, groups in enumerate(self.tempogram_groups):
            candidates = [g for g in groups if g['groups'][0]['value'] >= self.TEMPOGRAM_OFFSET_THRESHOLD]
            if not candidates:
                continue
                
            peak_scan_start = i
            
            for group in candidates:
                # Smooth the BPM estimate
                total_blocks = 0
                bpm_total = 0
                
                for j in range(max(0, i - self.TEMPOGRAM_SMOOTHING), 
                              min(len(self.tempogram_groups), i + self.TEMPOGRAM_SMOOTHING + 1)):
                    closest_group = None
                    for other_group in self.tempogram_groups[j]:
                        if (abs(other_group['center'] - group['center']) < self.TEMPOGRAM_GROUPING_WINDOW):
                            closest_group = other_group
                            break
                    
                    if closest_group:
                        bpm_total += closest_group['avg']
                        total_blocks += 1
                
                if total_blocks > 0:
                    bpm = round(bpm_total / total_blocks)
                    bpm_counts[bpm] = bpm_counts.get(bpm, 0) + 1
        
        # Get top BPMs
        bpm_results = []
        if bpm_counts:
            sorted_bpms = sorted(bpm_counts.items(), key=lambda x: x[1], reverse=True)
            total_confidence = sum(count for _, count in sorted_bpms[:5])
            
            for bpm, count in sorted_bpms[:5]:
                confidence = count / total_confidence if total_confidence > 0 else 0
                bpm_results.append({
                    'bpm': bpm,
                    'confidence': confidence
                })
        
        # Calculate offset for the top BPM
        offset_results = []
        if bpm_results:
            first_bpm = bpm_results[0]['bpm']
            offset_results = self._calculate_offset_for_bpm(first_bpm, peak_scan_start)
        
        return bpm_results, offset_results
    
    def _calculate_offset_for_bpm(self, bpm: float, peak_scan_start: int) -> List[Dict]:
        """Calculate offset options for a given BPM"""
        if not self.novelty_curve_isolated:
            return []
            
        beat_length_blocks = (60 / bpm) * (self.sample_rate / self.window_step)
        
        # Create analysis wave for beat tracking
        analyze_wave = []
        for i in range(self.OFFSET_LOOKAHEAD):
            beat_block = (i % beat_length_blocks) / beat_length_blocks
            t = 0
            n = 0
            for j in range(1, 5):  # harmonics 1-4
                weight = 1 / j
                phase_weight = max(1 - abs(round(beat_block * j) / j - beat_block) * 12, 0)
                n += phase_weight * weight
                t += weight
            analyze_wave.append(n / t if t > 0 else 0)
        
        # Test different offset positions
        options = []
        end_scan = min(len(self.novelty_curve_isolated), 
                      int(peak_scan_start + beat_length_blocks))
        
        for i in range(peak_scan_start, end_scan):
            if i + self.OFFSET_LOOKAHEAD >= len(self.novelty_curve_isolated):
                break
                
            # Calculate correlation with beat pattern
            response = 0
            for j in range(self.OFFSET_LOOKAHEAD):
                if i + j < len(self.novelty_curve_isolated):
                    response += analyze_wave[j] * self.novelty_curve_isolated[i + j]
            
            offset = -((i * self.window_step) / self.sample_rate) % (60 / bpm)
            options.append({
                'offset': offset,
                'response': response
            })
        
        # Sort by response strength
        options.sort(key=lambda x: x['response'], reverse=True)
        
        # Return top 5 with confidence percentages
        if options:
            total_response = sum(opt['response'] for opt in options[:5])
            offset_results = []
            
            for opt in options[:5]:
                confidence = opt['response'] / total_response if total_response > 0 else 0
                offset_results.append({
                    'offset': round(opt['offset'], 3),
                    'confidence': confidence
                })
            
            return offset_results
        
        return []
    
    def calculate_beat_times(self, bpm: float, offset: float, audio_duration: float = None) -> List[float]:
        """Calculate beat times for a given BPM and offset"""
        if audio_duration is None:
            if self.audio_data is None:
                raise ValueError("Audio data not loaded and no duration provided")
            audio_duration = len(self.audio_data) / self.sample_rate
        
        beat_interval = 60.0 / bpm  # seconds per beat
        beat_times = []
        
        # Start from the offset and generate beats
        current_time = offset
        while current_time < audio_duration:
            if current_time >= 0:  # Only include positive times
                beat_times.append(round(current_time, 3))
            current_time += beat_interval
        
        return beat_times

def smedit_analyze_audio(audio_path: str, threshold: float = 0.3, bpm_range = [80,200]):
    """Analyze audio file for tempo and offset"""
    detector = SMEditAudioSyncDetector(min_bpm=bpm_range[0], max_bpm=bpm_range[1])
    
    # Load audio
    detector.load_audio(audio_path)
    
    # Detect onsets
    onsets = detector.detect_onsets(threshold=threshold)
    
    # Detect tempo and offset
    bpm_results, offset_results = detector.detect_tempo_and_offset()
    
    # Calculate beat times for each BPM estimate
    audio_duration = len(detector.audio_data) / detector.sample_rate
    beat_times = {}
    
    for bpm_result in bpm_results:
        bpm = bpm_result['bpm']
        # Use the best offset for this BPM (first one if available)
        if offset_results:
            offset = offset_results[0]['offset']
        else:
            offset = 0.0
        
        beats = detector.calculate_beat_times(bpm, offset, audio_duration)
        beat_times[bpm] = beats
    print(f"Best bpm, offset: {bpm_results[0]}, {offset_results[0]}")
    
    return {
        'bpm_results': bpm_results,
        'offset_results': offset_results,
        'onsets': onsets,
        'beat_times': beat_times,
        'detector': detector
    }

def get_template():
    template = """\
#TITLE:{title};
#ARTIST:{artist};
#MUSIC:{music_fp};
#OFFSET:{offset};
#BPMS:{bpm};
#STOPS:;
{charts}\
"""
    return template

def get_chart_template():
    chart_template = """\
    #NOTES:
    dance-single:
    ITGPT:
    {ccoarse}:
    {cfine}:
    0.0,0.0,0.0,0.0,0.0:
    {measures};\
    """
    return chart_template

def ez_name(x):
    """
    Cleans and formats a given string x by removing spaces, replacing non-alphanumeric characters with underscores (_), 
    and ensuring it returns a string suitable for naming files or directories.
    _______
    ez_name("Hello World! 2023")  # Returns 'HelloWorld_2023'
    """
    x = ''.join(x.strip().split())
    x_clean = []
    for char in x:
        if char.isalnum():
            x_clean.append(char)
        else:
            x_clean.append('_')
    return ''.join(x_clean)

def get_subdirs(root, choose=False):
    """
    Lists the names of all subdirectories within a given root directory. 
    Optionally, it allows the user to select specific subdirectories to return.
    """
    subdir_names = sorted([x for x in os.listdir(root) if os.path.isdir(os.path.join(root, x))])
    if choose:
        for i, subdir_name in enumerate(subdir_names):
            print('{}: {}'.format(i, subdir_name))
        subdir_idxs = [int(x) for x in input('Which subdir(s)? ').split(',')]
        subdir_names = [subdir_names[i] for i in subdir_idxs]
    return subdir_names
    

def open_dataset_fps(*args):
    datasets = []
    for data_fp in args:
        if not data_fp:
            datasets.append([])
            continue

        with open(data_fp, 'r') as f:
            song_fps = f.read().split()
        dataset = []
        for song_fp in song_fps:
            with open(song_fp, 'rb') as f:
                dataset.append(pickle.load(f))
        datasets.append(dataset)
    return datasets[0] if len(datasets) == 1 else datasets

def windowize(dataset, frames = 7, front_set = 'None', go_backwards = False, take_windows = None, return_type = 'numpy'):
    if type(dataset) == list:
        dataset = np.array(dataset)
    dslen = dataset.shape[0]
    ds_shape = list(dataset.shape)
    ds_shape[0] = frames
    if front_set == 'None':
        front = np.zeros(ds_shape)
    elif front_set == 'min':
        front = np.ones(ds_shape)*np.min(dataset)
    else:
        front = np.array([front_set for i in range(frames)])
    if go_backwards:
        dataset = np.append(dataset, front, axis = 0)
    else:
        dataset = np.append(front, dataset, axis = 0)
    if take_windows is not None:
        new_ds = [dataset[i:i+1+frames] for i in take_windows]
    else:
        new_ds = [dataset[i:i+1+frames] for i in range(dslen)]
    if return_type == 'list':
        return new_ds
    elif return_type == 'numpy':
        return np.array(new_ds)
    else:
        raise NotImplementedError('o_o')

def sparse_to_categorical(val, max_val):
    a = np.zeros(max_val+1)
    a[val] = 1
    return a

def unfoldify(listy, base = 4):
    out = np.zeros(base*len(listy))
    for i in range(len(listy)):
        if listy[i] != 0:
            out[int(base*i+listy[i]-1)] = 1
    return out

def sparceify(listy, base = 4):
    out = 0
    for i in range(len(listy)):
        if listy[i] != 0:
            out += (listy[i])*(base**i)
    return out

def get_dataset_fp_list(*args):
    datasets = []
    for data_fp in args:
        if not data_fp:
            datasets.append([])
            continue

        with open(data_fp, 'r') as f:
            song_fps = f.read().split()
        dataset = []
        for song_fp in song_fps:
            dataset.append(song_fp)
        datasets.append(dataset)
    return datasets[0] if len(datasets) == 1 else datasets


def make_onset_feature_context(song_features, frame_idx, radius, left_radius = False):
    nframes = song_features.shape[0]
    
    assert nframes > 0
    if left_radius:
        frame_idxs = range(frame_idx - left_radius, frame_idx + radius + 1)
    else:
        frame_idxs = range(frame_idx - radius, frame_idx + radius + 1)
    context = np.zeros((len(frame_idxs),) + song_features.shape[1:], dtype=song_features.dtype)
    for i, frame_idx in enumerate(frame_idxs):
        if frame_idx >= 0 and frame_idx < nframes:
            context[i] = song_features[frame_idx]
        else:
            context[i] = np.ones_like(song_features[0])*np.log(1e-16)

    return context

def make_onset_feature_context_range(song_features, start_idx, end_idx, radius = 0, frame_density = 32):
    nframes = song_features.shape[0]

    start_idx, end_idx = int(start_idx*100), int(end_idx*100)
    
    assert nframes > 0

    frame_idxs = np.linspace(start_idx - radius, end_idx + radius, num = frame_density, endpoint = False).astype(int)
    context = np.zeros((len(frame_idxs),) + song_features.shape[1:], dtype=song_features.dtype)
    for i, frame_idx in enumerate(frame_idxs):
        if frame_idx >= 0 and frame_idx < nframes:
            context[i] = song_features[frame_idx]
        else:
            context[i] = np.ones_like(song_features[0])*np.log(1e-16)

    return context

def front_null(dataset, frames = 7, front_set = 'None', back_null = False):
    if type(dataset) == list:
        dataset = np.array(dataset)
    ds_shape = list(dataset.shape)
    ds_shape[0] = frames

    if front_set == 'min':
        front = np.ones(ds_shape) * np.min(dataset)
    elif front_set == 'None':
        front = np.zeros(ds_shape)
    else:
        front = np.array([front_set for i in range(frames)])
    dataset = np.append(front, dataset, axis = 0)
    if back_null:
        dataset = np.append(dataset, front, axis = 0)
    return dataset

def create_analyzers(fs=44100.0,
                     nhop=512,
                     nffts=[1024, 2048, 4096],
                     mel_nband=80,
                     mel_freqlo=27.5,
                     mel_freqhi=16000.0):
    """
    Creates a list of pre-computed Mel filterbanks matching the structural 
    expectations of the multi-resolution FFT pipeline.
    """
    analyzers = []
    for nfft in nffts:
        # Generates a matrix of shape (mel_nband, (nfft // 2) + 1)
        mel_basis = librosa.filters.mel(
            sr=fs,
            n_fft=nfft,
            n_mels=mel_nband,
            fmin=mel_freqlo,
            fmax=mel_freqhi,
            htk=False,
            norm='slaney'
        )
        analyzers.append(mel_basis)
    return analyzers

def extract_mel_feats(audio_fp, analyzers, fs=44100.0, nhop=512, nffts=[1024, 2048, 4096], log_scale=True):
    """
    Extracts multi-resolution log-mel spectrogram features.
    Guarantees perfectly uniform frame counts across all FFT channels.
    """
    # Load full audio in mono
    samples, _ = librosa.load(audio_fp, sr=fs, mono=True)
    
    feat_channels = []
    for nfft, mel_basis in zip(nffts, analyzers):
        # center=True ensures the frame count is floor(len(samples)/nhop) + 1 for all nfft sizes
        stft_matrix = librosa.stft(
            y=samples,
            n_fft=nfft,
            hop_length=nhop,
            window='blackmanharris',
            center=True
        )
        magnitude = np.abs(stft_matrix)
        
        # Matrix dot product: (mel_nband, bins) dot (bins, frames) -> (mel_nband, frames)
        mel_feats = np.dot(mel_basis, magnitude)
        
        # Transpose to (frames, mel_nband) to align with original sequential processing loop
        feat_channels.append(mel_feats.T)

    # np.stack results in shape: (channels, frames, mel_nband)
    # Transpose (1, 2, 0) reorders this exactly to: (frames, mel_nband, channels)
    feat_channels = np.transpose(np.stack(feat_channels), (1, 2, 0))

    if log_scale:
        feat_channels = np.log(feat_channels + 1e-16)

    return feat_channels

def extract_BPM(audio_fp, min_tempo=100, max_tempo=200):
    """
    Extracts BPM, beat timestamps, intervals, and zero-beat offset using librosa.
    """
    fs = 44100.0
    audio, _ = librosa.load(audio_fp, sr=fs, mono=True)
    
    # Run the beat tracker
    start_bpm = (min_tempo + max_tempo) / 2.0
    tempo, beat_frames = librosa.beat.beat_track(
        y=audio, 
        sr=fs, 
        hop_length=512, 
        start_bpm=start_bpm
    )
    
    # Safely extract scalar float BPM across different librosa version return types
    bpm = float(tempo[0]) if isinstance(tempo, (np.ndarray, list)) else float(tempo)
    
    # Convert tracked frame indices into absolute times (seconds)
    beat_times = librosa.frames_to_time(beat_frames, sr=fs, hop_length=512)
    
    # Safeguard downstream calculations against empty detections
    if len(beat_times) > 1:
        offset = 2 * beat_times[0] - beat_times[1]
        beat_intervals = np.diff(beat_times)
    elif len(beat_times) == 1:
        offset = beat_times[0] - (60.0 / bpm)
        beat_intervals = np.array([])
    else:
        offset = 0.0
        beat_intervals = np.array([])
        
    beat_dict = {
        'BPM': bpm, 
        'offset': offset, 
        'beats': beat_times, 
        'beat_intervals': beat_intervals
    }
    return beat_dict

def quick_reducify(ds, indices):
    return [[a[i] for i in indices] for a in ds]

def weighted_pick(weights):
    t = np.cumsum(weights)
    s = np.sum(weights)
    return(min(int(np.searchsorted(t, np.random.rand(1)*s)), 256))

def unravel_onehot(onehot, base):
    if onehot == 0:
        return '0000'
    else:
        out = ''
        while onehot:
            onehot, r = divmod(onehot, base)
            out += str(r)
        while len(out)<4:
            out += '0'
        return out

def downsample(dataset, down_key=2):
    return [[data[i] for i in range(0,len(data),down_key)] for data in dataset]

def label_to_vect_dict(labels):
    values = [list(a) for a in labels]
    max_len = np.lcm.reduce(np.unique([len(a) for a in values if len(a) != 0]))

    new_values = [np.zeros((max_len,)) for a in values]
    for i in range(len(new_values)):
        num_ticks = len(values[i])
        if num_ticks != 0:
            step = max_len/num_ticks
            for j in range(0, max_len, int(step)):
                new_values[i][j] = values[i][int(j/step)]
    new_dict = {k : v for k , v in zip(labels, new_values)}

    return new_dict

def ddc_string_to_step(string, narrow_types = 4):
    listy = [int(a) for a in list(string)]
    out = np.zeros((4*narrow_types))
    for i in range(len(listy)):
        out[narrow_types*i + listy[i]] = 1
    return out
    
def pickle_box(fp):
    #Load into a temporary namespace to avoid reference pollution
    with open(fp, 'rb') as f:
        data = pickle.load(f)
    return data


def get_bespoke_length_bracket(length_minutes):
    """
    Maps a song's duration in minutes directly to its bespoke bracket name.
    Matches the 'song_length' output format from your set_bpm function.
    """
    if length_minutes <= 1:    return "0-1 min"
    elif length_minutes <= 2:  return "1-2 min"
    elif length_minutes <= 4:  return "2-4 min"
    elif length_minutes <= 6:  return "4-6 min"
    elif length_minutes <= 10: return "6-10 min"
    elif length_minutes <= 16: return "10-16 min"
    elif length_minutes <= 30: return "16-30 min"
    elif length_minutes <= 60: return "30-1 hr"
    else:                      return "longer than an hour"

def get_bpm_bracket(bpm):
    """Buckets BPM into 10-step intervals (e.g., 140-150, 150-160)."""
    lower_bound = int(np.floor(bpm / 10) * 10)
    upper_bound = lower_bound + 10
    return f"{lower_bound}-{upper_bound}"

def get_difficulty_range_distribution(registry, target_bpm, target_length_minutes):
    """
    Finds charts matching the target song's brackets, calculates the 10th to 90th 
    difficulty percentile range, and returns 5 evenly distributed, distinct integer difficulties.
    If rounding causes duplicates, it expands down from the bottom to ensure 5 unique steps.
    """
    target_bpm_bracket = get_bpm_bracket(target_bpm)
    target_len_bracket = get_bespoke_length_bracket(target_length_minutes)
    
    # Filter registry to build our bracket population
    matched_difficulties = []
    for chart in registry:
        chart_bpm_bracket = get_bpm_bracket(chart['bpm'])
        
        # The registry stores length_seconds, so we convert it to minutes to compare
        chart_len_minutes = chart['length_seconds'] / 60.0
        chart_len_bracket = get_bespoke_length_bracket(chart_len_minutes)
        
        if chart_bpm_bracket == target_bpm_bracket and chart_len_bracket == target_len_bracket:
            matched_difficulties.append(int(chart['difficulty']))
            #print(chart.keys())
            #print(chart.values())
            
    # Fallback/Safety Check if data is sparse
    if len(matched_difficulties) < 2:
        print(f"Warning: Minimal dataset found for BPM {target_bpm_bracket} & Length '{target_len_bracket}'.")
        if not matched_difficulties:
            return []
        return [matched_difficulties[0]] * 5

    # Calculate 10th and 90th percentiles
    pct_5, pct_95 = np.percentile(matched_difficulties, [5, 95])
    
    # Generate 5 evenly distributed points across the span and round
    distributed_difficulties = np.linspace(pct_5, pct_95, num=5)
    final_integers = np.round(distributed_difficulties).astype(int).tolist()
    
    # --- DEDUPLICATION LOGIC ---
    # Convert to a sorted list of unique numbers to find missing slots
    unique_ints = sorted(list(set(final_integers)))
    
    while len(unique_ints) < 5:
        bottom_val = unique_ints[0]
        if bottom_val <= 1:
            # Absolute safety floor reached; break out to prevent entering 0 or negative numbers
            break
        # Prepend the next lowest integer to the list
        unique_ints.insert(0, bottom_val - 1)
        
    # If the range expanded downwards, trim it to exactly 5 elements from the bottom 
    # (or pad right with duplicates if bottoming out at 1 leaves it short)
    if len(unique_ints) > 5:
        unique_ints = unique_ints[:5]
    elif len(unique_ints) < 5:
        # Extreme fallback if we crashed against the floor of 1 and still don't have 5 elements
        while len(unique_ints) < 5:
            unique_ints.append(unique_ints[-1])
            
    final_integers = unique_ints
    # ----------------------------
    
    print(f"Targeting -> BPM: {target_bpm_bracket} | Length: {target_len_bracket}")
    print(f"Matched {len(matched_difficulties)} dataset charts. 10th-90th range: [{int(pct_5)} - {int(pct_95)}]")
    
    return final_integers

def load_registry(registry_path='chart_registry.pkl'):
    with open(registry_path, 'rb') as f:
        return pickle.load(f)