import json, os, pickle, queue, random, threading

import numpy as np
from tqdm import tqdm

from util import *


# ──────────────────────────────────────────────────────────────────────────────
# Data pipeline
# ──────────────────────────────────────────────────────────────────────────────

def _count_onset_chunks(dataset_fp_list, max_beats=2000, min_chunk=50):
    """Scan the dataset once to count the total number of training chunks."""
    count = 0
    for fp in tqdm(dataset_fp_list, desc="Scanning files"):
        with open(fp, 'rb') as f:
            charts = pickle.load(f)
        feats_fp = charts[3]
        with open(feats_fp, 'rb') as f:
            feats = pickle.load(f)
        for chart_idx in range(len(charts[0])):
            newsong = [charts[i][chart_idx] for i in range(3)]
            features = np.array([make_onset_feature_context_range(feats, x[0], x[1])
                                 for x in newsong[0]])
            features = (features - features.mean(0)) / (features.std(0) + 1e-6)
            n_beats  = features.shape[0]
            bpm_seq  = [_[1] for _ in newsong[1]]
            
            # Enforce min_chunk during BPM boundary parsing
            boundaries = [0]
            for i in range(1, n_beats):
                if int(round(bpm_seq[i])) != int(round(bpm_seq[i - 1])):
                    if i - boundaries[-1] >= min_chunk:
                        boundaries.append(i)
            
            # Catch trailing tiny chunks and merge backward if necessary
            if n_beats - boundaries[-1] < min_chunk and len(boundaries) > 1:
                boundaries.pop()
            boundaries.append(n_beats)
            
            for bi in range(len(boundaries) - 1):
                start, end = boundaries[bi], boundaries[bi + 1]
                count += max(1, int(np.ceil((end - start) / max_beats)))
    return count


def generatorify_from_fp_list_onset(dataset_fp_list, enc_dict,
                                    max_beats=2000, min_chunk=50, edge_buffer=1000,
                                    prefetch=4,
                                    cache_len_fp="epoch_len_cache.json",
                                    shuffle = True):
    """
    Threaded generator yielding (features, bpm, difficulty, enc_targets) tuples.
    BPM-homogeneous chunks are extracted and long chunks are split at low-energy
    boundaries to keep sequences within max_beats.
    Returns: (generator, epoch_len)
    """
    if shuffle:
        random.shuffle(dataset_fp_list)

    # Load or compute epoch length
    if os.path.exists(cache_len_fp):
        with open(cache_len_fp) as f:
            epoch_len = json.load(f).get("epoch_len")
    else:
        epoch_len = None

    if epoch_len is None:
        print("Counting chunks to determine epoch length…")
        epoch_len = _count_onset_chunks(dataset_fp_list, max_beats, min_chunk)
        with open(cache_len_fp, "w") as f:
            json.dump({"epoch_len": epoch_len}, f)
        print(f"Cached epoch length = {epoch_len}")

    def _split_by_energy(features, bpm_seq, start, end, edge_buffer, min_chunk, max_beats):
        """Split a BPM-homogeneous segment that exceeds max_beats at low-energy points."""
        chunk_len  = end - start
        beat_energy = np.sqrt(np.mean(features[start:end] ** 2, axis=(1, 2, 3)))
        candidates = np.arange(edge_buffer, chunk_len - edge_buffer)
        sorted_c   = candidates[np.argsort(beat_energy[candidates])]
        boundaries = [0, chunk_len]
        for b in sorted_c:
            for j in range(len(boundaries) - 1):
                s, e = boundaries[j], boundaries[j + 1]
                if s < b < e and (e - s) > max_beats and (b - s) > min_chunk and (e - b) > min_chunk:
                    boundaries.insert(j + 1, b)
                    break
            if all(boundaries[k + 1] - boundaries[k] <= max_beats
                   for k in range(len(boundaries) - 1)):
                break
        return [(start + boundaries[j], start + boundaries[j + 1])
                for j in range(len(boundaries) - 1)]

    def _inner():
        k = 0
        chart_out = True
        charts = feats = None

        while True:
            if chart_out:
                with open(dataset_fp_list[k], 'rb') as f:
                    charts = pickle.load(f)
                with open(charts[3], 'rb') as f:
                    feats = pickle.load(f)
                k = (k + 1) % len(dataset_fp_list)
                chart_tape = 0
                chart_out  = False


            try: newsong = [charts[i][chart_tape] for i in range(3)]
            except:
                chart_tape = 0
                chart_out = True
                continue
            chart_tape += 1
            if chart_tape == len(charts[0]):
                del charts
                chart_out = True

            features = np.array([make_onset_feature_context_range(feats, x[0], x[1])
                                  for x in newsong[0]])
            if chart_out:
                del feats

            # Normalise per-sequence
            features = (features - features.mean(0)) / (features.std(0) + 1e-6)

            n_beats = features.shape[0]
            diff    = newsong[1][0][0]
            bpm_seq = [_[1] for _ in newsong[1]]

            # Split at BPM change boundaries
            boundaries = [0]
            for i in range(1, n_beats):
                if int(round(bpm_seq[i])) != int(round(bpm_seq[i - 1])):
                    if i - boundaries[-1] >= min_chunk:
                        boundaries.append(i)
            
            # Prevent a tiny atomic fragment at the very end of the song
            if n_beats - boundaries[-1] < min_chunk and len(boundaries) > 1:
                boundaries.pop()
            boundaries.append(n_beats)

            for bi in range(len(boundaries) - 1):
                start, end = boundaries[bi], boundaries[bi + 1]
                bpm_val    = int(round(bpm_seq[start]))
                enc        = [enc_dict[x] for x in newsong[2][start:end]]

                if (end - start) > max_beats:
                    sub_ranges = _split_by_energy(features, bpm_seq, start, end,
                                                  edge_buffer, min_chunk, max_beats)
                    for s, e in sub_ranges:
                        yield features[s:e], bpm_val, diff, enc[s - start:e - start]
                else:
                    yield features[start:end], bpm_val, diff, enc


    # Wrap with a prefetch queue
    def _threaded():
        q = queue.Queue(maxsize=prefetch)
        def _produce():
            for item in _inner():
                q.put(item)
        threading.Thread(target=_produce, daemon=True).start()
        while True:
            yield q.get()

    return _threaded(), epoch_len


def get_inputs_and_gens_onset(train_fp, test_fp, labels_fp, use_all_charts=False, shuffle = True):
    trn_ds, tst_ds = get_dataset_fp_list(train_fp, test_fp)
    with open(labels_fp, 'rb') as f:
        labels = pickle.load(f)
    enc_dict = label_to_vect_dict(labels)
    train_gen, n_train = generatorify_from_fp_list_onset(
        trn_ds, enc_dict, cache_len_fp="train_epoch_len_cache.json", shuffle = shuffle)
    test_gen,  n_test  = generatorify_from_fp_list_onset(
        tst_ds, enc_dict, cache_len_fp="test_epoch_len_cache.json", shuffle = False)
    return train_gen, test_gen, n_train, n_test