# ITGPT

Automatic chart generation for DDR/ITG charts.

![ITGPT Teaser Image](ITGPT_teaser.png)

## HF Spaces

Our model is available for use on HuggingFace spaces! Try it [here!](https://huggingface.co/spaces/miguelomalley/ITGPT)

## Paper

If you use this code in your work, please provide a reference to:

```
@misc{omalley2026itgpttransformerbasedarchitecture,
      title={ITGPT: A Transformer Based Architecture for the Generation of Dance Dance Revolution and In the Groove Charts}, 
      author={Miguel O'Malley},
      year={2026},
      eprint={2607.14148},
      archivePrefix={arXiv},
      primaryClass={cs.SD},
      url={https://arxiv.org/abs/2607.14148}, 
}

```
## Getting Started

For pure generation, download the GUI version and follow the instructions on-screen.

For training your own ITGPT model,  clone this repository and navigate to it in the terminal.

### Prerequisites

Install an appropriate CUDA driver if you want to take advantage of GPU acceleration.

Use a Python environment of version 3+.

### Installation

Navigate to the repository and run:
```
pip install -r requirements.txt
```

## Usage

To train your own onset model, place your charts in the raw/songs folder as your would for Stepmania/ITGmania. The file structure should look like:
```
raw/songs/<your song folders>
```
For example, to reproduce the dataset from the paper, download the following packs from one of the many sources (e.g, itgpacks.com)

```
Fraxtil's Arrow Arrangements
Fraxtil's Beast Beats
Fraxtil's Cute Charts
Sweet Arrows and Hella Steps Vols 1-4
Tsunamix III
```

and place them like
```
raw/songs/Fraxtil's Arrow Arrangements
```

Then run
```
python smfiler.py
```
To train your own ITGPT onset model, run
```
python onset.py
```
To train your own ITGPT sym model, run
```
python sym.py
```
To generate charts, place your desired songs in the input_songs_for_generation folder. Then, run

```
python generate_charts.py
```