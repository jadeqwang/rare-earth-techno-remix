"""
Chart generation script for DDR/ITG.

Phase 1 (onset)   — For each difficulty, the OnsetModel computes step placements through hierarchical attention
Phase 2 (symbolic) — For each difficulty, the SymModel autoregressively selects
                    the specific arrow combination for each placed step, conditioned
                    on the surrounding audio and beat-timing context.
Phase 3 (output)  — Converts generated steps to .sm format and writes output files.
"""

import argparse
import os
import shutil

import numpy as np
import torch
from tinytag import TinyTag
from tqdm import tqdm

from util import (
    create_analyzers, extract_mel_feats, set_bpm,
    make_onset_feature_context, make_onset_feature_context_range,
    get_template, get_chart_template, unravel_onehot, load_registry,
    get_difficulty_range_distribution
)
from onset import OnsetModel, OnsetConfig
from sym import ITGPTSymModel as SymModel
from sym_config import ModelConfig as SymConfig

DIFFICULTY_INDEX_MAP = {
            "Beginner": 0,
            "Easy": 1,
            "Medium": 2,
            "Hard": 3,
            "Challenge": 4
        }

# ──────────────────────────────────────────────────────────────────────────────
# Helpers
# ──────────────────────────────────────────────────────────────────────────────

def _split_at_energy_boundaries(features, max_beats, min_chunk, edge_buffer):
    """
    Split a feature array that exceeds max_beats into chunks, choosing
    split points at the lowest-energy beats to minimise musical disruption.
    Returns a list of (start, end) index pairs.
    """
    n = len(features)
    beat_energy = np.sqrt(np.mean(features ** 2, axis=tuple(range(1, features.ndim))))
    candidates  = np.arange(edge_buffer, n - edge_buffer)
    sorted_c    = candidates[np.argsort(beat_energy[candidates])]
    boundaries  = [0, n]
    for b in sorted_c:
        for i in range(len(boundaries) - 1):
            s, e = boundaries[i], boundaries[i + 1]
            if s < b < e and (e - s) > max_beats and (b - s) > min_chunk and (e - b) > min_chunk:
                boundaries.insert(i + 1, b)
                break
        if all(boundaries[i + 1] - boundaries[i] <= max_beats
               for i in range(len(boundaries) - 1)):
            break
    return list(zip(boundaries[:-1], boundaries[1:]))


def _split_sym_chunks(audio_list, aux_list, min_len=50, max_len=1000):
    """
    Split parallel (audio, aux) lists into chunks of length ∈ [min_len, max_len].
    Returns list of (audio_chunk, aux_chunk) pairs.
    """
    T      = len(audio_list)
    chunks = []
    start  = 0
    while start < T:
        end = min(start + max_len, T)
        chunks.append((audio_list[start:end], aux_list[start:end]))
        start = end

    # Merge short trailing chunk into predecessor
    if len(chunks) > 1 and len(chunks[-1][0]) < min_len:
        prev_a, prev_x = chunks[-2]
        last_a, last_x = chunks[-1]
        if len(prev_a) + len(last_a) <= max_len:
            chunks[-2] = (prev_a + last_a, prev_x + last_x)
            chunks.pop()
    return chunks


# ──────────────────────────────────────────────────────────────────────────────
# Main generation function
# ──────────────────────────────────────────────────────────────────────────────

def generate_charts(
    onset_model_fp="trained_models/onset_stamina.pt",
    sym_model_fp="trained_models/sym_stamina.pt",
    threshold=0.5,
    max_beats=2000,
    min_chunk=50,
    edge_buffer=500,
    in_directory="input_songs_for_generation",
    out_directory="generated_charts",
    diffs=("Beginner", "Easy", "Medium", "Hard", "Challenge"),
    maxstep=12,
    bpm_method="SMEdit",
    model_frame_density=32,
    max_bpm = 200,
    min_bpm = 100,
):
    if torch.cuda.is_available():
        device = torch.device("cuda")
    elif hasattr(torch, "xpu") and torch.xpu.is_available():
        device = torch.device("xpu")
    else:
        device = torch.device("cpu")

    print(f"Using device: {device}")
    chart_data = load_registry('chart_registry.pkl')

    # ── Load onset model ─────────────────────────────────────────────────────
    print("Loading step placement model…")
    onset_ckpt = torch.load(onset_model_fp, map_location=device, weights_only=False)
    onset_cfg  = onset_ckpt.get("cfg", OnsetConfig())
    onset_model = OnsetModel(onset_cfg).to(device)
    onset_model.load_state_dict(onset_ckpt["model_state"])
    onset_model.eval()

    # ── Load symbolic model ──────────────────────────────────────────────────
    print("Loading step selection model…")
    ModelConfig = SymConfig
    sym_ckpt  = torch.load(sym_model_fp, map_location=device, weights_only=False)
    sym_cfg   = sym_ckpt.get("cfg", SymConfig())
    sym_model = SymModel(3, sym_cfg).to(device)
    sym_model.load_state_dict(sym_ckpt["model"])
    sym_model.eval()

    analyzers = create_analyzers(nhop=441)
    subdiv    = maxstep * 4
    template       = get_template()
    chart_template = get_chart_template()

    os.makedirs(out_directory, exist_ok=True)

    # ── Process each song ────────────────────────────────────────────────────
    for song_fn in os.listdir(in_directory):
        if not song_fn.lower().endswith((".mp3", ".ogg", ".wav", ".aiff")):
            continue

        song_in       = os.path.join(in_directory, song_fn)
        song_title    = os.path.splitext(song_fn)[0]
        out_song_path = os.path.join(out_directory, song_title)

        # Clean and recreate output directory
        if os.path.isdir(out_song_path):
            shutil.rmtree(out_song_path)
        os.makedirs(out_song_path)

        print(f"\nProcessing: {song_fn}")

        # Analyse BPM / beats
        try:
            beats, subdiv_beats, bpm_shift_times, offset, bpm_str, song_length, bpm = \
                set_bpm(song_in, bpm_method=bpm_method, min_tempo=min_bpm, max_tempo=max_bpm)
        except Exception as e:
            print(f"BPM detection failed with exception:{e}. Skipping {song_fn}.")
            break

        # Derive difficulty levels from BPM and song length
        diff_reg = get_difficulty_range_distribution(
            registry=chart_data, 
            target_bpm=bpm, 
            target_length_minutes=song_length
        )
        fine_diffs = {}
        for d in diffs:
            if d in DIFFICULTY_INDEX_MAP:
                idx = DIFFICULTY_INDEX_MAP[d]
                fine_diffs[d] = diff_reg[idx]


        # Metadata parsing via TinyTag
        try:
            tag = TinyTag.get(song_in)
            title = tag.title.replace(":", "").replace(";", "") if tag.title else song_title
            artist = tag.artist if tag.artist else "Unknown Artist"
        except Exception as e:
            print(f"  Warning: Metadata extraction failed ({e}). Using file fallback labels.")
            title = song_title.replace(":", "").replace(";", "")
            artist = "Unknown Artist"

        # Audio features
        song_feats = extract_mel_feats(song_in, analyzers, nhop=441)

        # Build per-beat BPM index (for chunk BPM assignment)
        beat_bpm = np.zeros(len(beats) - 1)
        shift_lvl = 0
        for i in range(len(beats) - 1):
            if shift_lvl + 1 < len(bpm_shift_times) and i >= bpm_shift_times[shift_lvl + 1][0]:
                shift_lvl += 1
            beat_bpm[i] = bpm_shift_times[shift_lvl][1]

        # ── Phase 1: onset detection ──────────────────────────────────────
        all_placed_times: dict = {}

        for diff in diffs:
            fine = fine_diffs[diff]

            # Extract per-beat spectrogram windows and normalise
            beat_contexts = np.array([
                make_onset_feature_context_range(song_feats, beats[i], beats[i + 1],
                                                  frame_density=model_frame_density)
                for i in range(len(beats) - 1)
            ])
            beat_contexts = (beat_contexts - beat_contexts.mean(0)) / (beat_contexts.std(0) + 1e-6)

            # Chunk into BPM-homogeneous segments ≤ max_beats
            n_beats    = len(beat_contexts)
            chunk_segs = [(0, n_beats)] if n_beats <= max_beats else \
                         _split_at_energy_boundaries(beat_contexts, max_beats, min_chunk, edge_buffer)

            onset_results = []
            with torch.no_grad():
                for start, end in chunk_segs:
                    chunk_feat = beat_contexts[start:end]
                    chunk_bpm  = float(beat_bpm[start])
                    x = torch.tensor(chunk_feat, dtype=torch.float32, device=device).unsqueeze(0)
                    # Autoregressive onset generation
                    onsets = onset_model.generate(x, chunk_bpm, fine, threshold=threshold)
                    #print(onsets[0])
                    #print(onsets[1])
                    onset_results.append(onsets)

            stream_outs = np.concatenate(onset_results, axis=0)  # (T_beats, out_dim)

            # Map onset positions to absolute times
            placed_times = []
            for beat_idx, out in enumerate(stream_outs):
                try:
                    next_time = beats[beat_idx + 1]
                except IndexError:
                    next_time = 2 * beats[beat_idx] - beats[beat_idx - 1]
                cur_time  = beats[beat_idx]
                time_gap  = next_time - cur_time
                step_gap  = time_gap / max(len(out), 1)
                t = cur_time
                for step_on in out:
                    if step_on:
                        placed_times.append(t)
                    t += step_gap

            # Snap placed times to nearest subdivision beat
            buckets     = (subdiv_beats[1:] + subdiv_beats[:-1]) / 2
            snapped     = subdiv_beats[np.digitize(placed_times, buckets)]
            placed_times = np.sort(np.unique(snapped))

            # Compute beat-delta features for each placed step
            beat_positions = np.interp(placed_times, beats, np.arange(len(beats)))
            beat_deltas = []
            for i, b in enumerate(beat_positions):
                since_prev = 0.0 if i == 0 else round(b - beat_positions[i - 1], 2)
                until_next = 0.0 if i == len(beat_positions) - 1 else round(beat_positions[i + 1] - b, 2)
                beat_deltas.append((since_prev, until_next))

            audio_contexts = [make_onset_feature_context(song_feats, int(t * 100), 20)
                               for t in placed_times]

            print(f"  {diff}: {len(placed_times)} steps placed.")
            all_placed_times[diff] = {
                "times":  placed_times,
                "audio":  audio_contexts,
                "deltas": beat_deltas,
            }

        # ── Phase 2: step selection ───────────────────────────────────────
        all_selected: dict = {}

        for diff in diffs:
            data   = all_placed_times[diff]
            chunks = _split_sym_chunks(data["audio"], data["deltas"],
                                        min_len=50, max_len=450)
            results = []
            total_steps = sum(len(c[0]) for c in chunks)
            
            # Keep track of the last chunk's generated tokens for context overlap
            prev_tokens = None 

            with torch.no_grad(), tqdm(total=total_steps, desc=f"Selecting {diff}") as pbar:
                for chunk_audio, chunk_aux in chunks:
                    audio = torch.as_tensor(np.array(chunk_audio),
                                             dtype=torch.float32).unsqueeze(0).to(device)
                    aux   = torch.as_tensor(np.array(chunk_aux),
                                             dtype=torch.float32).unsqueeze(0).to(device)
                    
                    # Extract the last 50 tokens from the previous chunk, if available
                    prefix = prev_tokens[-50:] if prev_tokens is not None else None

                    preds = sym_model.generate(
                        audio_steps=audio, aux_steps=aux,
                        max_len=audio.shape[1],
                        temperature=1.0, top_p=0.9,
                        progress_callback=pbar.update,
                        prefix_tokens=prefix, # <-- Pass the context overlap here
                    )
                    results.append(preds)
                    prev_tokens = preds # Keep track for the next iteration

            token_ids = np.concatenate(results, axis=0)
            all_selected[diff] = np.array([unravel_onehot(t, 4) for t in token_ids])
            print(f"  {diff}: {len(token_ids)} steps selected.")

        # ── Phase 3: write output files ───────────────────────────────────
        diff_chart_txts = []
        for diff in diffs:
            fine         = fine_diffs[diff]
            placed_times = all_placed_times[diff]["times"]
            steps        = all_selected[diff]
            assert len(placed_times) == len(steps)

            time_to_step = dict(zip(placed_times, steps))
            full_steps   = [time_to_step.get(t, "0000") for t in subdiv_beats]
            measures     = np.split(full_steps, list(range(subdiv, len(full_steps), subdiv)))
            measures_txt = "\n,\n".join(["\n".join(m) for m in measures])

            diff_chart_txts.append(chart_template.format(
                ccoarse=diff, cfine=fine, measures=measures_txt))

        audio_out_name = os.path.basename(song_in)
        sm_txt = template.format(
            title=title, artist=artist, music_fp=audio_out_name,
            bpm=bpm_str, offset=-offset,
            charts="\n".join(diff_chart_txts),
        )

        audio_out_fp = os.path.join(out_song_path, audio_out_name)
        if not os.path.exists(audio_out_fp):
            shutil.copyfile(song_in, audio_out_fp)
        with open(os.path.join(out_song_path, f"{song_title}.sm"), "w") as f:
            f.write(sm_txt)
        print(f"  Saved → {out_song_path}")


def generate_charts_gui(
    onset_model_fp="trained_models/onset_stamina.pt",
    sym_model_fp="trained_models/sym_stamina.pt",
    threshold=0.5,
    max_beats=2000,
    min_chunk=50,
    edge_buffer=500,
    in_directory="input_songs_for_generation",
    out_directory="generated_charts",
    diffs=("Beginner", "Easy", "Medium", "Hard", "Challenge"),
    maxstep=12,
    bpm_method="AV",
    model_frame_density=32,
    log_callback = None,
    progress_callback = None,
    max_bpm = 200,
    min_bpm = 100,
):
    def log(msg):
        if log_callback:
            log_callback(msg)
        print(msg)
    if torch.cuda.is_available():
        device = torch.device("cuda")
    elif hasattr(torch, "xpu") and torch.xpu.is_available():
        device = torch.device("xpu")
    else:
        device = torch.device("cpu")
    log(f"Using device: {device}")
    chart_data = load_registry('chart_registry.pkl')

    # ── Load onset model ─────────────────────────────────────────────────────
    log("Loading step placement model…")
    onset_ckpt = torch.load(onset_model_fp, map_location=device, weights_only=False)
    onset_cfg  = onset_ckpt.get("cfg", OnsetConfig())
    onset_model = OnsetModel(onset_cfg).to(device)
    onset_model.load_state_dict(onset_ckpt["model_state"])
    onset_model.eval()

    # ── Load symbolic model ──────────────────────────────────────────────────
    log("Loading step selection model…")
    ModelConfig = SymConfig
    sym_ckpt  = torch.load(sym_model_fp, map_location=device, weights_only=False)
    sym_cfg   = sym_ckpt.get("cfg", SymConfig())
    sym_model = SymModel(3, sym_cfg).to(device)
    sym_model.load_state_dict(sym_ckpt["model"])
    sym_model.eval()

    analyzers = create_analyzers(nhop=441)
    subdiv    = maxstep * 4
    template       = get_template()
    chart_template = get_chart_template()

    os.makedirs(out_directory, exist_ok=True)

    # ── Process each song ────────────────────────────────────────────────────
    for song_fn in os.listdir(in_directory):
        if not song_fn.lower().endswith((".mp3", ".ogg", ".wav", ".aiff")):
            continue

        song_in       = os.path.join(in_directory, song_fn)
        song_title    = os.path.splitext(song_fn)[0]
        out_song_path = os.path.join(out_directory, song_title)

        # Clean and recreate output directory
        if os.path.isdir(out_song_path):
            shutil.rmtree(out_song_path)
        os.makedirs(out_song_path)

        log(f"\nProcessing: {song_fn}")

        # Analyse BPM / beats
        try:
            beats, subdiv_beats, bpm_shift_times, offset, bpm_str, song_length, bpm = \
                set_bpm(song_in, bpm_method=bpm_method, min_tempo=min_bpm, max_tempo=max_bpm)
        except Exception as e:
            log(f"BPM detection failed with exception:{e}. Skipping {song_fn}.")
            break

        # Derive difficulty levels from BPM and song length
        diff_reg = get_difficulty_range_distribution(
            registry=chart_data, 
            target_bpm=bpm, 
            target_length_minutes=song_length
        )
        fine_diffs = {}
        for d in diffs:
            if d in DIFFICULTY_INDEX_MAP:
                idx = DIFFICULTY_INDEX_MAP[d]
                fine_diffs[d] = diff_reg[idx]

        # Metadata parsing via TinyTag
        try:
            tag = TinyTag.get(song_in)
            title = tag.title.replace(":", "").replace(";", "") if tag.title else song_title
            artist = tag.artist if tag.artist else "Unknown Artist"
        except Exception as e:
            log(f"  Warning: Metadata extraction failed ({e}). Using file fallback labels.")
            title = song_title.replace(":", "").replace(";", "")
            artist = "Unknown Artist"

        # Audio features
        song_feats = extract_mel_feats(song_in, analyzers, nhop=441)

        # Build per-beat BPM index (for chunk BPM assignment)
        beat_bpm = np.zeros(len(beats) - 1)
        shift_lvl = 0
        for i in range(len(beats) - 1):
            if shift_lvl + 1 < len(bpm_shift_times) and i >= bpm_shift_times[shift_lvl + 1][0]:
                shift_lvl += 1
            beat_bpm[i] = bpm_shift_times[shift_lvl][1]

        # ── Phase 1: onset detection ──────────────────────────────────────
        all_placed_times: dict = {}

        for diff in diffs:
            fine = fine_diffs[diff]

            # Extract per-beat spectrogram windows and normalise
            beat_contexts = np.array([
                make_onset_feature_context_range(song_feats, beats[i], beats[i + 1],
                                                  frame_density=model_frame_density)
                for i in range(len(beats) - 1)
            ])
            beat_contexts = (beat_contexts - beat_contexts.mean(0)) / (beat_contexts.std(0) + 1e-6)

            # Chunk into BPM-homogeneous segments ≤ max_beats
            n_beats    = len(beat_contexts)
            chunk_segs = [(0, n_beats)] if n_beats <= max_beats else \
                         _split_at_energy_boundaries(beat_contexts, max_beats, min_chunk, edge_buffer)

            onset_results = []
            with torch.no_grad():
                for start, end in chunk_segs:
                    chunk_feat = beat_contexts[start:end]
                    chunk_bpm  = float(beat_bpm[start])
                    x = torch.tensor(chunk_feat, dtype=torch.float32, device=device).unsqueeze(0)
                    # Autoregressive onset generation
                    onsets = onset_model.generate(x, chunk_bpm, fine, threshold=threshold)
                    onset_results.append(onsets)

            stream_outs = np.concatenate(onset_results, axis=0)  # (T_beats, out_dim)

            # Map onset positions to absolute times
            placed_times = []
            for beat_idx, out in enumerate(stream_outs):
                try:
                    next_time = beats[beat_idx + 1]
                except IndexError:
                    next_time = 2 * beats[beat_idx] - beats[beat_idx - 1]
                cur_time  = beats[beat_idx]
                time_gap  = next_time - cur_time
                step_gap  = time_gap / max(len(out), 1)
                t = cur_time
                for step_on in out:
                    if step_on:
                        placed_times.append(t)
                    t += step_gap

            # Snap placed times to nearest subdivision beat
            buckets     = (subdiv_beats[1:] + subdiv_beats[:-1]) / 2
            snapped     = subdiv_beats[np.digitize(placed_times, buckets)]
            placed_times = np.sort(np.unique(snapped))

            # Compute beat-delta features for each placed step
            beat_positions = np.interp(placed_times, beats, np.arange(len(beats)))
            beat_deltas = []
            for i, b in enumerate(beat_positions):
                since_prev = 0.0 if i == 0 else round(b - beat_positions[i - 1], 2)
                until_next = 0.0 if i == len(beat_positions) - 1 else round(beat_positions[i + 1] - b, 2)
                beat_deltas.append((since_prev, until_next))

            audio_contexts = [make_onset_feature_context(song_feats, int(t * 100), 20)
                               for t in placed_times]

            log(f"  {diff}: {len(placed_times)} steps placed.")
            all_placed_times[diff] = {
                "times":  placed_times,
                "audio":  audio_contexts,
                "deltas": beat_deltas,
            }

        # ── Phase 2: step selection ───────────────────────────────────────
        all_selected: dict = {}

        for diff in diffs:
            data   = all_placed_times[diff]
            chunks = _split_sym_chunks(data["audio"], data["deltas"], min_len=50, max_len=450)
            results = []
            total_steps = sum(len(c[0]) for c in chunks)
            
            prev_tokens = None 

            with torch.no_grad(), tqdm(total=total_steps, desc=f"Selecting {diff}") as pbar:
                if progress_callback:
                    progress_callback(0.0, f"Selecting steps for {diff}...")

                steps_completed = 0
                for chunk_audio, chunk_aux in chunks:
                    audio = torch.as_tensor(np.array(chunk_audio), dtype=torch.float32).unsqueeze(0).to(device)
                    aux   = torch.as_tensor(np.array(chunk_aux), dtype=torch.float32).unsqueeze(0).to(device)
                    
                    prefix = prev_tokens[-50:] if prev_tokens is not None else None

                    def update_bridge(n):
                        nonlocal steps_completed
                        pbar.update(n)
                        steps_completed += n
                        if progress_callback:
                            progress_callback(float(steps_completed / total_steps), f"Selecting {diff}: {steps_completed}/{total_steps}")

                    preds = sym_model.generate(
                        audio_steps=audio, aux_steps=aux,
                        max_len=audio.shape[1],
                        temperature=1.0, top_p=0.9,
                        progress_callback=update_bridge,
                        prefix_tokens=prefix,
                    )
                    results.append(preds)
                    prev_tokens = preds

                token_ids = np.concatenate(results, axis=0)
                all_selected[diff] = np.array([unravel_onehot(t, 4) for t in token_ids])
                if log_callback:
                    log_callback(f"  {diff}: {len(token_ids)} steps selected.")

        # ── Phase 3: write output files ───────────────────────────────────
        diff_chart_txts = []
        for diff in diffs:
            fine         = fine_diffs[diff]
            placed_times = all_placed_times[diff]["times"]
            steps        = all_selected[diff]
            assert len(placed_times) == len(steps)

            time_to_step = dict(zip(placed_times, steps))
            full_steps   = [time_to_step.get(t, "0000") for t in subdiv_beats]
            measures     = np.split(full_steps, list(range(subdiv, len(full_steps), subdiv)))
            measures_txt = "\n,\n".join(["\n".join(m) for m in measures])

            diff_chart_txts.append(chart_template.format(
                ccoarse=diff, cfine=fine, measures=measures_txt))

        audio_out_name = os.path.basename(song_in)
        sm_txt = template.format(
            title=title, artist=artist, music_fp=audio_out_name,
            bpm=bpm_str, offset=-offset,
            charts="\n".join(diff_chart_txts),
        )

        audio_out_fp = os.path.join(out_song_path, audio_out_name)
        if not os.path.exists(audio_out_fp):
            shutil.copyfile(song_in, audio_out_fp)
        with open(os.path.join(out_song_path, f"{song_title}.sm"), "w") as f:
            f.write(sm_txt)
        log(f"  Saved → {out_song_path}")


# ──────────────────────────────────────────────────────────────────────────────
# CLI
# ──────────────────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Generate DDR/ITG charts from audio files.")
    parser.add_argument("--onset_model",    default="trained_models/onset_stamina.pt")
    parser.add_argument("--sym_model",      default="trained_models/sym_stamina.pt")
    parser.add_argument("--in_dir",         default="input_songs_for_generation")
    parser.add_argument("--out_dir",        default="generated_charts")
    parser.add_argument("--threshold",      type=float, default=0.5)
    parser.add_argument("--max_beats",      type=int,   default=2000)
    parser.add_argument("--min_chunk",      type=int,   default=1000)
    parser.add_argument("--edge_buffer",    type=int,   default=500)
    parser.add_argument("--maxstep",        type=int,   default=12)
    parser.add_argument("--bpm_method",     default="AV",
                        choices=["DDCL", "AV", "SMEdit"])
    parser.add_argument("--frame_density",  type=int,   default=32)
    parser.add_argument("--max_bpm",         type=int,   default=200)
    parser.add_argument("--min_bpm",         type=int,   default=100)
    parser.add_argument("--diffs", nargs="+", default=["Beginner", "Easy", "Medium", "Hard", "Challenge"])

    args = parser.parse_args()

    generate_charts(
        onset_model_fp=args.onset_model,
        sym_model_fp=args.sym_model,
        threshold=args.threshold,
        max_beats=args.max_beats,
        min_chunk=args.min_chunk,
        edge_buffer=args.edge_buffer,
        in_directory=args.in_dir,
        out_directory=args.out_dir,
        maxstep=args.maxstep,
        bpm_method=args.bpm_method,
        model_frame_density=args.frame_density,
        max_bpm=args.max_bpm,
        min_bpm=args.min_bpm,
        diffs=args.diffs,
    )